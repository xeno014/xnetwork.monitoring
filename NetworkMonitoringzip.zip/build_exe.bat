@echo off
REM Builds dist\XenoTechIPMonitor.exe  (run from the project folder)
setlocal
cd /d "%~dp0"

echo [1/3] Installing dependencies...
python -m pip install --upgrade pip || goto :fail
python -m pip install -r requirements.txt pyinstaller || goto :fail

echo [2/3] Building executable...
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name XenoTechIPMonitor ^
  --icon assets\xenotech.ico ^
  --paths src ^
  --add-data "assets;assets" ^
  --add-data "config\devices.json;config" ^
  --hidden-import pystray._win32 ^
  src\main.py || goto :fail

echo [3/3] Done.
echo.
echo   dist\XenoTechIPMonitor.exe
echo.
echo On first run it creates config\ and logs\ next to the .exe.
echo Put the .exe in a normal user folder (Desktop, Documents), not Program Files.
pause
exit /b 0

:fail
echo.
echo Build failed - see messages above.
pause
exit /b 1
